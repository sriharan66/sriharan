<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomePage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        integrity="sha384-tViUnnbYAV00FLIhhi3v/dWt3Jxw4gZQcNoSCxCIFNJVCx7/D55/wXsrNIRANwdD" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <div class="content">
        <div class="container-fluid bgimage-1 d-flex justify-content-center align-items-center mt-2">
            <div id="carouselExampleIndicators" class="carousel slide">

                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-sm-12">
                                    <div class="mb-5 text-center text-lg-start">
                                        <h1 class="display-3 fw-bold">
                                            <span> Sale 20% Off</span><br> On Everything
                                        </h1>
                                        <p>
                                            Explicabo esse amet tempora quibusdam laudantium, laborum eaque magnam
                                            fugiat hic? Esse
                                            dicta
                                            aliquid error
                                            repudiandae earum suscipit fugiat molestias, veniam, vel architecto
                                            veritatis delectus
                                            repellat
                                            modi impedit
                                            sequi.
                                        </p>
                                        <button class="btn text-white p-2 px-5 w-md-50" type="button">Shop Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-sm-12">
                                    <div class="mb-5 text-center text-lg-start">
                                        <h1 class="display-3 fw-bold">
                                            <span> Dummy text</span><br> On Everything
                                        </h1>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione quae, iure,
                                            officia blanditiis accusamus in quo mollitia possimus debitis fugiat quam
                                            tempora reprehenderit quaerat dolores voluptatibus neque laborum culpa rerum
                                            voluptas. Labore pariatur possimus sequi?</p>

                                        <button class="btn  text-white p-2 px-5 w-md-50" type="button">Shop Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-sm-12">
                                    <div class="mb-5 text-center text-lg-start">
                                        <h1 class="display-3 fw-bold">
                                            <span> Dummy text-2</span><br> On Everything
                                        </h1>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione quae, iure,
                                            officia blanditiis accusamus in quo mollitia possimus debitis fugiat quam
                                            tempora reprehenderit quaerat dolores voluptatibus neque laborum culpa rerum
                                            voluptas. Labore pariatur possimus sequi?</p>

                                        <button class="btn  text-white p-2 px-5 w-md-50" type="button">Shop Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
        </div>


        <div class="container">
            <div class="row mt-3">
                <div class="col-12">
                    <h1 class="text-center display-4 fw-bold">
                        Why <span class="shop-underline">Shop</span> With Us
                    </h1>
                </div>
            </div>
            <div class="row mt-5 text-white shop-section">
                <div class="col-md-4 col-sm-12 mb-4">
                    <section>
                        <div class="card text-center h-100">
                            <i class="bi bi-truck mt-5" style="font-size: 2rem;"></i>
                            <div class="card-body">
                                <h5>Fast Delivery</h5>
                                <p>
                                    Variations of passages of Lorem Ipsum available
                                </p>
                            </div>
                        </div>
                    </section>
                </div>
                <div class="col-md-4 col-sm-12 mb-4">
                    <section>
                        <div class="card text-center h-100">
                            <i class="bi bi-truck mt-5" style="font-size: 2rem;"></i>
                            <div class="card-body">
                                <h5>Free Shipping</h5>
                                <p>
                                    Variations of passages of Lorem Ipsum available
                                </p>
                            </div>
                        </div>
                    </section>
                </div>
                <div class="col-md-4 col-sm-12 mb-4">
                    <section>
                        <div class="card text-center  h-100">
                            <i class="bi bi-truck mt-5" style="font-size: 2rem;"></i>
                            <div class="card-body">
                                <h5>Best Quality</h5>
                                <p>
                                    Variations of passages of Lorem Ipsum available
                                </p>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <div class="arrival-img">
            <div class="container-fluid bgimage-2 mt-5">
                <div class="row justify-content-end">
                    <div class="col-12 col-md-8 ">
                        <div class="arrival d-flex flex-column justify-content-center align-items-center vh-100 ">
                            <h1 class="fw-bold">#New Arrival</h1>
                            <p class=" w-50">
                                Vitae fugiat laboriosam officia perferendis provident aliquid voluptatibus dolorem,
                                fugit
                                ullam sit earum id eaque nisi hic?
                                Tenetur commodi, nisi rem vel, ea eaque ab ipsa, autem similique ex unde!
                            </p>
                            <button class="btn text-white p-2 w-md-50" style="background-color:#f7444e;"
                                type="button">Shop Now</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container home-product-section">
            <div class="row mt-5">
                <div class="col-12 product-underline">
                    <h2 class="text-center display-5 fw-bold">Our <span class="underline">Products</span></h2>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p1.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Men's Shirt
                                </h5>
                                <h5>
                                    $75
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p2.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Men's Shirt
                                </h5>
                                <h5>
                                    $80
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p3.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Women's Dress
                                </h5>
                                <h5>
                                    $68
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p4.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Women's Dress
                                </h5>
                                <h5>
                                    $70
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p5.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Women's Dress
                                </h5>
                                <h5>
                                    $75
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p6.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Women's Dress
                                </h5>
                                <h5>
                                    $58
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p7.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Women's Dress
                                </h5>
                                <h5>
                                    $80
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p8.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Men's Shirt
                                </h5>
                                <h5>
                                    $65
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p9.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Men's Shirt
                                </h5>
                                <h5>
                                    $65
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p10.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Men's Shirt
                                </h5>
                                <h5>
                                    $65
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p11.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Men's Shirt
                                </h5>
                                <h5>
                                    $65
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="section">
                        <div class="card text-center">
                            <div class="card-img mt-5">
                                <img src="Asserts/p12.png" alt="">
                            </div>
                            <div class="card-text d-flex flex-row justify-content-around my-5">
                                <h5>
                                    Women's Dress
                                </h5>
                                <h5>
                                    $65
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row my-5">
                <div class="col-12">
                    <div class="product-button text-center ">
                        <button class="btn p-2 text-white px-5" type="button">View All products</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid subscribe">
            <div class="container">
                <div class="row justify-content-center text-center my-5">
                    <div class="col-12 mt-5">
                        <h1>Subscribe To Get Discount Offers</h1>
                    </div>
                    <div class="col-12 mt-4">
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Facere, delectus.</p>
                    </div>
                    <div class="col-12 col-md-8 col-lg-6 mt-2">
                        <input type="email" class="form-control rounded-pill p-3" id="Email"
                            aria-describedby="emailHelp" placeholder="Enter Your Email">
                    </div>
                    <div class="col-12 mt-3">
                        <button class="btn rounded-pill px-5 py-2 my-4 text-white">SUBSCRIBE</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="row">
                <div class="col-12 text-center testimonial-underline">
                    <h1 class="display-5 fw-bold">Customer'<span class="underline">s Testimonial</span></h1>
                </div>
            </div>
            <div class="row testimonial mt-4 text-center mb-5">
                <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div>
                                <div
                                    class="row d-flex justify-content-center align-items-center align-self-center flex-column ">
                                    <div class="col-lg-8">
                                        <img class="rounded-circle mb-4" src="Asserts/client.jpg">
                                        <h5>Anna Trevor</h5>
                                        <p class="text-muted">Customer</p>
                                        <p class="text-muted">
                                            Dignissimos reprehenderit repellendus nobis error quibusdam? Atque animi
                                            sint unde quis
                                            reprehenderit, et, perspiciatis, debitis totam est deserunt eius officiis
                                            ipsum ducimus ad
                                            labore modi voluptatibus accusantium sapiente nam! Quaerat.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div>
                                <div class="row d-flex justify-content-center">
                                    <div class="col-lg-8">
                                        <img class="rounded-circle mb-4" src="Asserts/client.jpg">
                                        <h5>Anna Trevor</h5>
                                        <p class="text-muted">Dummy text</p>
                                        <p class="text-muted">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. At dolorum
                                            accusantium architecto? Expedita, earum eaque! Aliquam nobis accusamus
                                            nostrum sequi exercitationem dolor eligendi! Non, minus.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon rounded-circle" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next">
                        <span class="carousel-control-next-icon rounded-circle" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="home-footer">
            <div class="footer-start">
                <div class="container">
                    <div class="row mt-5">
                        <div class="footer-contact col-lg-3 col-md-6 col-sm-12 my-5">
                            <div>
                                <a href=""><img src="Asserts/Fammslogo.png"></a>
                            </div>
                            <div class="mt-4">
                                <p><strong>ADDRESS:</strong> 28 White tower, Street Name, New York City, USA</p>
                                <p><strong>TELEPHONE:</strong> +91 987 654 3210</p>
                                <p><strong>EMAIL:</strong> yourmain@gmail.com</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 my-5 ">
                            <div>
                                <h5><strong>MENU</strong></h5>
                            </div>
                            <div class="footer-menu d-flex flex-column mt-4">
                                <a href="">Home</a>
                                <a href="">About</a>
                                <a href="">Service</a>
                                <a href="">Testimonial</a>
                                <a href="">Blog</a>
                                <a href="">Contact</a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 my-5">
                            <div>
                                <h5><strong>ACCOUNT</strong></h5>
                            </div>
                            <div class="footer-account d-flex flex-column mt-4">
                                <a href="">Account</a>
                                <a href="">Checkout</a>
                                <a href="">Login</a>
                                <a href="">Register</a>
                                <a href="">Shopping</a>
                                <a href="">Widget</a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 my-5">
                            <div>
                                <h5><strong>NEWSLETTER</strong></h5>
                            </div>
                            <div class="mt-4">
                                <p>Subscribe by our newsletter and get updates.</p>
                            </div>
                            <div class="footer-newsletter input-group mb-4">
                                <input type="text" class="form-control" placeholder="Enter Your Mail"
                                    aria-label="Enter Your Mail" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button class="btn text-white  p-2" type="button">Subscribe</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid footer-end">
                <div class=" row">
                    <div class="col-12 text-center my-3">
                        <p>&copy; 2021 All Rights Reserved By <a href="">Free HTML Templates</a><br>Distributed By
                            <a href="">ThemeWagon</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>