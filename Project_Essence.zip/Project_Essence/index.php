<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="style.css">
    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include Owl Carousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <!-- Include Owl Carousel JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

</head>

<body>
    <!-- Header Including Starts Here -->

    <?php
    include("header.php")
        ?>

    <!-- Header Including Ends Here -->

    <div class="container-fluid collectionbg d-flex justify-content-center align-items-center mb-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-12">
                    <div class="collectionbg-text mb-5 text-lg-start">
                        <h6>asoss</h6>
                        <h2>New Collection</h2>
                        <button type="button" class="btn px-5 py-2 mt-4">VIEW COLLECTION</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container my-5">
        <div class="row garments">
            <div class="col-lg-4">
                <div class="cloth">
                    <div class="cloth-img d-flex justify-content-center align-items-center">
                        <div class="cloth-text">
                            <a href="">CLOTHING</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="shoe">
                    <div class="shoe-img d-flex justify-content-center align-items-center">
                        <div class="shoe-text">
                            <a href="">SHOES</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="accessories">
                    <div class="accessories-img d-img d-flex justify-content-center align-items-center">
                        <div class="accessories-text">
                            <a href="">ACCESSORIES</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="global-sale my-5">
        <div class="container globalsalebg">
            <div class="row justify-content-end">
                <div class="col-12 col-md-8 ">
                    <div class="sale-text d-flex flex-column justify-content-center align-items-center vh-75 my-5 ">
                        <h6 class="mt-5">-60%</h6>
                        <h2 class="display-4">Global Sale</h2>
                        <button type="button" class="btn btn-primary px-5 mt-4">Buy Now</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-5">
        <div class="row popular-text">
            <div class="col-12">
                <h2>Popular Products</h2>
            </div>
        </div>
        <div class="row mt-3">
            <div class="owl-carousel">
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-1.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-2.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">Add to Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-2.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-1.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">ADD TO CART</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-3.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-4.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">Add to Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-4.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-3.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">Add to Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-5.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-6.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">Add to Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-6.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-5.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">Add to Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-7.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-8.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">Add to Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="product-item">
                        <div class="product-img">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-8.jpg" alt="">
                            <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-7.jpg" alt="">
                        </div>
                        <div class="product-text mt-3">
                            <span>TOPSHOP</span>
                            <a href="">
                                <h6>Knot Front Mini Dress</h6>
                            </a>
                            <p>$80.00</p>
                            <div class="hover-content">
                                <div class="hover-link">
                                    <a href="#" class="btn">Add to Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>







    <div class="brandimage">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 d-flex flex-row justify-content-between align-items-center flex-wrap">
                    <div class="brand1">
                        <img src="assetsnew/BrandImages/brand1.png" alt="">
                    </div>
                    <div class="brand2">
                        <img src="assetsnew/BrandImages/brand2.png" alt="">
                    </div>
                    <div class="brand3">
                        <img src="assetsnew/BrandImages/brand3.png" alt="">
                    </div>
                    <div class="brand4">
                        <img src="assetsnew/BrandImages/brand4.png" alt="">
                    </div>
                    <div class="brand5">
                        <img src="assetsnew/BrandImages/brand5.png" alt="">
                    </div>
                    <div class="brand6">
                        <img src="assetsnew/BrandImages/brand6.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Including Starts Here -->

    <?php
    include("footer.php")
        ?>

    <!-- Footer Including Ends Here -->
    <script>
        $(document).ready(function () {
            $(".owl-carousel").owlCarousel({
                loop: true,
                margin: 10,
                nav: false,
                dots: false,
                autoplay: true, // Enable autoplay
                autoplayTimeout: 3000, // Time between slides in milliseconds (3000ms = 3 seconds)
                responsive: {
                    0: {
                        items: 1 // Display 1 item for mobile devices
                    },
                    600: {
                        items: 2 // Display 2 items for medium devices
                    },
                    1000: {
                        items: 4 // Display 3 items for larger devices
                    }
                }
            });
        });

    </script>


</body>

</html>