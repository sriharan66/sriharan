<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="blog.css">
</head>

<body>
<!-- Header Including Starts Here -->

<?php
    include("header.php")
        ?>

    <!-- Header Including Ends Here -->

    <div class="container-fluid blog-bg d-flex justify-content-center align-items-center mb-5">
        <h1 class="display-2 fw-bold">FASHION BLOG</h1>
    </div>

    <div class="container blog my-5">
        <div class="row my-5">
            <div class="col-lg-6 ">
                <div class="blogcontent">
                    <img src="assetsnew/BlogImages/blog1.jpg" alt="">
                    <div class="blog-text">
                        <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                    </div>
                    <div class="hover">
                        <div class="hovertext mt-3">
                            <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                        </div>
                        <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla,
                            mollis eu metus
                            in, sagittis fringilla tortor. Phasellus purus dignissim convallis.</p>
                        <a href="singleblog.php">Continue reading <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="blogcontent">
                    <img src="assetsnew/BlogImages/blog2.jpg" alt="">
                    <div class="blog-text">
                        <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                    </div>
                    <div class="hover">
                        <div class="hovertext mt-3">
                            <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                        </div>
                        <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla,
                            mollis eu metus
                            in, sagittis fringilla tortor. Phasellus purus dignissim convallis.</p>
                        <a href="singleblog.php">Continue reading <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row my-5">
            <div class="col-lg-6 ">
                <div class="blogcontent">
                    <img src="assetsnew/BlogImages/blog3.jpg" alt="">
                    <div class="blog-text">
                        <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                    </div>
                    <div class="hover">
                        <div class="hovertext mt-3">
                            <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                        </div>
                        <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla,
                            mollis eu metus
                            in, sagittis fringilla tortor. Phasellus purus dignissim convallis.</p>
                        <a href="singleblog.php">Continue reading <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="blogcontent">
                    <img src="assetsnew/BlogImages/blog4.jpg" alt="">
                    <div class="blog-text">
                        <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                    </div>
                    <div class="hover">
                        <div class="hovertext mt-3">
                            <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                        </div>
                        <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla,
                            mollis eu metus
                            in, sagittis fringilla tortor. Phasellus purus dignissim convallis.</p>
                        <a href="singleblog.php">Continue reading <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row my-5">
            <div class="col-lg-6 ">
                <div class="blogcontent">
                    <img src="assetsnew/BlogImages/blog5.jpg" alt="">
                    <div class="blog-text">
                        <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                    </div>
                    <div class="hover">
                        <div class="hovertext mt-3">
                            <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                        </div>
                        <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla,
                            mollis eu metus
                            in, sagittis fringilla tortor. Phasellus purus dignissim convallis.</p>
                        <a href="singleblog.php">Continue reading <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="blogcontent">
                    <img src="assetsnew/BlogImages/blog6.jpg" alt="">
                    <div class="blog-text">
                        <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                    </div>
                    <div class="hover">
                        <div class="hovertext mt-3">
                            <a href="#">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</a>
                        </div>
                        <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla,
                            mollis eu metus
                            in, sagittis fringilla tortor. Phasellus purus dignissim convallis.</p>
                        <a href="singleblog.php">Continue reading <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Footer Including Starts Here -->

<?php 
include ("footer.php")
?>

<!-- Footer Including Ends Here -->


</body>

</html>