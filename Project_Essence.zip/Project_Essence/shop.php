<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="shop.css">
</head>

<body>
    <!-- Header Page Including Starts Here -->
    <?php
    include 'header.php';
    ?>
    <!-- Header Page Including Ends Here -->


    <div class="container-fluid shop-bg d-flex justify-content-center align-items-center">
        <h2 class="fw-bold">DRESSES</h2>
    </div>

    <div class="container">
        <div class="row my-5">
            <div class="col-12 col-md-6 col-lg-3">
                <div class="shop-content-text">
                    <div class="categories">
                        <h6 class="mb-5 mt-3">Catagories</h6>
                        <div class="categories-menu-list">
                            <ul class="list-unstyled">
                                <li class="mb-1"><a href="">All</a></li>
                                <li class="mb-1"><a href="">Bodysuits</a></li>
                                <li class="mb-1"><a href="">Dresses</a></li>
                                <li class="mb-1"><a href="">Hoodies & Sweats</a></li>
                                <li class="mb-1"><a href="">Jackets & Coats</a></li>
                                <li class="mb-1"><a href="">Jeans</a></li>
                                <li class="mb-1"><a href="">Pants & Leggings</a></li>
                                <li class="mb-1"><a href="">Rompers & Jumpsuits</a></li>
                                <li class="mb-1"><a href="">Shirts & Blouses</a></li>
                                <li class="mb-1"><a href="">Shirts</a></li>
                                <li class="mb-1"><a href="">Sweaters & Knits</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="filters my-5">
                        <h6>Filter by</h6>
                        <p class="mt-4">PRICE</p>
                        <div class="range">
                            <div class="range-slider">
                                <div class="slider">
                                    <div class="progress">
                                    </div>
                                </div>
                                <div class="range-input">
                                    <input type="range" class="range-min" min="0" max="500" value="300">
                                    <input type="range" class="range-max" min="0" max="500" value="400">
                                </div>
                                <div class="range-price mt-3">RANGE: $49.00 - $360.00</div>
                            </div>
                        </div>
                    </div>

                    <div class="colors">
                        <p>COLOR</p>

                        <div class="color-list">
                            <ul class="d-flex flex-wrap list-unstyled">
                                <li><a href="#" class="color1"></a></li>
                                <li><a href="#" class="color2"></a></li>
                                <li><a href="#" class="color3"></a></li>
                                <li><a href="#" class="color4"></a></li>
                                <li><a href="#" class="color5"></a></li>
                                <li><a href="#" class="color6"></a></li>
                                <li><a href="#" class="color7"></a></li>
                                <li><a href="#" class="color8"></a></li>
                                <li><a href="#" class="color9"></a></li>
                                <li><a href="#" class="color10"></a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="brands">
                        <p>BRANDS</p>
                        <div class="brand-list mt-4">
                            <ul class="list-unstyled">
                                <li><a href="">Asos</a></li>
                                <li><a href="">Mango</a></li>
                                <li><a href="">River Island</a></li>
                                <li><a href="">Topshop</a></li>
                                <li><a href="">Zara</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-9">
                <div class="row">
                    <div class="products-shop">
                        <div class="row">
                            <div class="col-12">
                                <div class="products-filter d-flex flex-row justify-content-between flex-wrap ">
                                    <div class="products-found">
                                        <p><span>186 </span>PRODUCTS FOUND</p>
                                    </div>
                                    <div class="sort d-flex flex-row mt-lg-0 mt-3">
                                        <p>SORT BY:</p>
                                        <form action="#" method="">
                                            <select name="select" id="sortby">
                                                <option value="highestrated" class="current">HIGHEST RATED</option>
                                                <option value="newest">NEWEST</option>
                                                <option value="price1">PRICE: $$ - $</option>
                                                <option value="price2">PRICE: $ - $$</option>
                                            </select>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row my-5">
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-1.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-2.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-2.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-1.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-3.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-4.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-4.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-3.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-5.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-6.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-6.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-5.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-7.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-8.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-8.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-7.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="product-item">
                                    <div class="product-img">
                                        <img class="img-fluid" src="assetsnew/ProductsImages/product-9.jpg" alt="">
                                        <img class="img-fluid hover-img" src="assetsnew/ProductsImages/product-8.jpg"
                                            alt="">
                                    </div>
                                    <div class="product-text mt-1">
                                        <span>TOPSHOP</span>
                                        <a href="">
                                            <h6>Knot Front Mini Dress</h6>
                                        </a>
                                        <p>$80.00</p>
                                        <div class="hover-content">
                                            <div class="hover-link">
                                                <a href="#" class="btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>


    <!-- Footer Page Including Starts Here -->
    <?php
    include 'footer.php';
    ?>
    <!-- Footer Page Including Ends Here -->


</body>

</html>