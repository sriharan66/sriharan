<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProductDetails</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="product-details.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

</head>

<body>
    <!-- Header Page Including Starts Here -->
    <?php
    include 'header.php';
    ?>
    <!-- Header Page Including Ends Here -->


    <div class="container-fluid mt-4 mt-lg-0">
        <div class="row">
            <div class="col-12 col-md-6 products">
                <div class="owl-carousel owl-theme">
                    <div class="item product-item">
                        <div class="product-img-1">
                            <img src="assetsnew/ProductsImages/product-big-1.jpg" alt="">
                        </div>
                    </div>
                    <div class="item product-item">
                        <div class="product-img-2">
                            <img src="assetsnew/ProductsImages/product-big-2.jpg" alt="">
                        </div>
                    </div>
                    <div class="item product-item">
                        <div class="product-img-3">
                            <img src="assetsnew/ProductsImages/product-big-3.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 my-lg-5">
                <div class="product-details-content d-flex flex-column justify-content-center my-lg-5">
                    <span class="name mt-5">MANGO</span>
                    <a href="">
                        <h2 class="mt-2">One Shoulder Glitter Midi Dress</h2>
                    </a>
                    <p class="price mt-3">
                        <span class="oldprice">$65.00</span>
                        <span class="newprice">$49.00</span>
                    </p>
                    <p class="mt-3"> Mauris viverra cursus ante laoreet eleifend. Donec vel fringilla ante. Aenean finibus velit id
                        urna
                        vehicula, nec maximus est sollicitudin.</p>

                    <form method="" action="">
                        <div class="form-options d-flex flex-row justify-content-evenly mt-5">
                            <div class="size d-flex ">
                                <select class="form-select" id="size">
                                    <option selected value="value">Size: XL</option>
                                    <option value="value">Size: X</option>
                                    <option value="value">Size: M</option>
                                    <option value="value">Size: S</option>
                                </select>
                            </div>

                            <div class="color d-flex ">
                                <select class="form-select" id="color">
                                    <option selected value="value">Color: Black</option>
                                    <option value="value">Color: White</option>
                                    <option value="value">Color: Red</option>
                                    <option value="value">Color: Purple</option>
                                </select>
                            </div>
                        </div>

                    </form>
                </div>
                <div class="cart d-flex align-items-center mt-3 mt-lg-0 mb-5 justify-content-center">

                    <button type="submit" name="cart" class="btn bg-primary text-white px-4">Add
                        to
                        cart</button>
                    <div class="heart">
                        <a href="#" class="favme fa fa-heart"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Footer Page Including Starts Here -->
    <?php
    include 'footer.php';
    ?>
    <!-- Footer Page Including Ends Here -->


    <script>
        $(document).ready(function () {
            $(".owl-carousel").owlCarousel({
                items: 1,
                loop: true,
                nav: true,
                navText: [
                    "<img src='assetsnew/ProductsImages/long-arrow-left.svg' alt='Previous'>",
                    "<img src='assetsnew/ProductsImages/long-arrow-right.svg' alt='Next'>"
                ],
                dots: false,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true
            });
        });
    </script>


</body>

</html>