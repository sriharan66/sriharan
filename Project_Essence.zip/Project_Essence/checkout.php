<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="checkout.css">
</head>

<body>
    <!-- Header Page Including Starts Here -->
    <?php
    include 'header.php';
    ?>
    <!-- Header Page Including Ends Here -->
    <div class="container-fluid checkout-bg d-flex justify-content-center align-items-center text-center">
        <div class="row">
            <h2 class="fw-bold">CHECKOUT</h2>
        </div>
    </div>

    <div class="container">
        <div class="row my-5">

            <div class="row my-4 d-flex flex-row justify-content-between">
                <div class="col-12 col-md-6 col-lg-6 mt-5">
                    <div class="col-12 col-md-6">
                        <div class="billing-details">
                            <div class="billing-text">
                                <h5>Billing Address</h5>
                            </div>
                        </div>
                    </div>
                    <div class="checkout-details">
                        <form action="">
                            <div class="name">
                                <div class="firstname">
                                    <label for="firstname" class="form-label">FIRST NAME<span>*</span></label>
                                    <input type="text" class="form-control" id="firstname">
                                </div>
                                <div class="lastname">
                                    <label for="lastname" class="form-label">LAST NAME<span>*</span></label>
                                    <input type="text" class="form-control" id="lastname">
                                </div>
                            </div>
                            <div class="companyname my-3">
                                <label for="companyname" class="form-label">COMPANY NAME<span>*</span></label>
                                <input type="text" class="form-control" id="companyname">
                            </div>
                            <div class="country my-3">
                                <label for="country" class="form-label">COUNTRY<span>*</span></label>
                                <select class="form-select" aria-label="Default select example" id="country">
                                    <option selected>United States</option>
                                    <option value="unitedkingdom">United Kingdom</option>
                                    <option value="germany">Germany</option>
                                    <option value="france">France</option>
                                    <option value="india">India</option>
                                    <option value="australia">Australia</option>
                                    <option value="brazil">Brazil</option>
                                    <option value="canada">Canada</option>
                                </select>
                            </div>
                            <div class="address my-3">
                                <label for="address1" class="form-label">ADDRESS<span>*</span></label>
                                <input type="text" class="form-control mb-2" id="address1">
                                <input type="text" class="form-control" id="address">
                            </div>
                            <div class="postcode my-3">
                                <label for="postcode" class="form-label">POSTCODE<span>*</span></label>
                                <input type="text" class="form-control" id="postcode">
                            </div>
                            <div class="town/city my-3">
                                <label for="city" class="form-label">TOWN/CITY<span>*</span></label>
                                <input type="text" class="form-control" id="city">
                            </div>
                            <div class="province my-3">
                                <label for="province" class="form-label">PROVINCE<span>*</span></label>
                                <input type="text" class="form-control" id="province">
                            </div>
                            <div class="number my-3 ">
                                <label for="number" class="form-label">PHONE NUMBER<span>*</span></label>
                                <input type="tel" class="form-control" id="number">
                            </div>
                            <div class="mail my-3">
                                <label for="mail" class="form-label">EMAIL ADDRESS<span>*</span></label>
                                <input type="mail" class="form-control" id="email">
                            </div>
                            <div class="check my-3">
                                <div class="terms">
                                    <div class="form-check my-2">
                                        <input class="form-check-input1" type="checkbox" id="terms">
                                        <label class="form-check-label1" for="terms">
                                            TERMS AND CONDITIONS
                                        </label>
                                    </div>
                                </div>
                                <div class="account">
                                    <div class="form-check my-2">
                                        <input class="form-check-input2" type="checkbox" id="account">
                                        <label class="form-check-label2" for="account">
                                            CREATE AN ACCOUNT
                                        </label>
                                    </div>
                                </div>
                                <div class="subscribe">
                                    <div class="form-check my-2">
                                        <input class="form-check-input3" type="checkbox" id="subscribe">
                                        <label class="form-check-label3" for="subscribe">
                                            SUBSCRIBE TO OUR NEWSLETTER
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-5">
                    <div class="order-details">
                        <order-text>
                            <h5>Your Order</h5>
                            <p>The Details</p>
                        </order-text>
                        <div class="amount-details">
                            <ul class="product-details-text">
                                <li><span>Product</span> <span>Total</span></li>

                                <li><span>Cocktail Yellow dress</span><span>$59.90</span></li>
                                <li><span>Subtotal</span><span>$59.90</span></li>
                                <li><span>Shipping</span><span>Free</span></li>
                                <li><span>Total</span><span>$59.90</span></li>
                            </ul>
                        </div>
                        <div class="payment-type">
                            <form action="">
                                <div class="form-check">
                                    <input class="form-check-input1" type="radio" name="paymentType" id="paymentType"
                                        value="onlinepayment">
                                    <label class="form-check-label1" for="paymentType">
                                        ONLINE PAYMENT
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input2" type="radio" name="paymentType" id="paymentType"
                                        value="cashOnDelivery">
                                    <label class="form-check-label2" for="paymentType">
                                        CASH ON DELIVERY
                                    </label>
                                </div>
                                <button type="button" class="btn my-5">PLACE ORDER</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Page Including Starts Here -->
    <?php
    include 'footer.php';
    ?>
    <!-- Footer Page Including Ends Here -->


</body>

</html>