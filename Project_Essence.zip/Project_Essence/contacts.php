<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="contacts.css">
</head>

<body>
<!-- Header Including Starts Here -->

<?php
    include("header.php")
        ?>

    <!-- Header Including Ends Here -->

<div class="container-fluid contacts-bg d-flex justify-content-center align-items-center text-center">
<div class="div">
    <h2 class="fw-bold">CONTACTS</h2>
</div>
</div>

    <div class="container-fluid">
        <div class="row my-5">
            <div class="contact-form col-lg-8">
                <div class="col-lg-4">
                    <form>
                        <div class="form-inputs">
                            <input type="text" class="form-control bg-light bg-gradient" id="input1"
                                placeholder="Your name *"><br>
                            <input type="email" class="form-control bg-light bg-gradient" id="input2"
                                placeholder="Your email *"><br>
                            <input type="tel" class="form-control bg-light bg-gradient" id="input3"
                                placeholder="Your mobile *"><br>
                            <input type="text" class="form-control bg-light bg-gradient" id="input4"
                                placeholder="Subject">
                        </div>
                    </form>
                </div>

                <div class="col-lg-4 message ">
                    <form>
                        <textarea class="form-control bg-light bg-gradient" id="input5" rows="4"></textarea>

                        <p class="mt-4">By clicking Send a message button,you agree to use our "Form" terms And consent
                            cookie usage
                            in
                            browser.</p>
                        <button type="submit" class="btn">Send a message</button>
                    </form>
                </div>

            </div>
            <div class="col-lg-4 my-3">
                <div class="contact-us">
                    <div class="contact-us-text">
                        <h2>How to Find Us</h2>
                        <p>Mauris viverra cursus ante laoreet eleifend. Donec vel fringilla ante. Aenean finibus velit
                            id urna vehicula, nec maximus est sollicitudin.</p>
                    </div>
                    <div class="contact-details">
                        <p>ADDRESS:<span>10 Suffolk st Soho, London, UK</span></p>
                        <p>TELEPHONE:<span>+12 34 567 890
                            </span> </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Footer Including Starts Here -->

<?php 
include ("footer.php")
?>

<!-- Footer Including Ends Here -->

</body>

</html>