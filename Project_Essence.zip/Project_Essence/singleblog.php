<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SingleBlog</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="singleblog.css">
</head>

<body>
<!-- Header Including Starts Here -->

<?php
    include("header.php")
        ?>

    <!-- Header Including Ends Here -->

    <div class="container-fluid">
        <div class="row single-bg">
        </div>
    </div>

    <div class="container-fluid single-blog">
        <div class="row ">
            <div class="col-lg-9">
                <div class="single-content">
                    <h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis perferendis rem accusantium
                        ducimus animi nesciunt expedita omnis aut quas molestias!</h2>
                    <p>Mauris viverra cursus ante laoreet eleifend. Donec vel fringilla ante. Aenean finibus velit id
                        urna vehicula, nec maximus est sollicitudin. Praesent at tempus lectus, eleifend blandit felis.
                        Fusce augue arcu, consequat a nisl aliquet, consectetur elementum turpis. Donec iaculis lobortis
                        nisl, et viverra risus imperdiet eu. Etiam mollis posuere elit non sagittis. Lorem ipsum dolor
                        sit amet, consectetur adipiscing elit. Nunc quis arcu a magna sodales venenatis. Integer non
                        diam sit amet magna luctus mollis ac eu nisi. In accumsan tellus ut dapibus blandit.</p>
                    <blockquote class="my-5">
                        <h6><i class="fa fa-quote-left" aria-hidden="true"></i> Quisque sagittis non ex eget vestibulum.
                            Sed nec ultrices dui. Cras et sagittis erat. Maecenas pulvinar, turpis in dictum tincidunt,
                            dolor nibh lacinia lacus.</h6>
                        <span>Liam Neeson</span>
                    </blockquote>
                    <p>Praesent ac magna sed massa euismod congue vitae vitae risus. Nulla lorem augue, mollis non est
                        et, eleifend elementum ante. Nunc id pharetra magna. Praesent vel orci ornare, blandit mi sed,
                        aliquet nisi. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos
                        himenaeos.</p>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="single-images mb-lg-5">
                    <div class="bgblog-1">
                        <img src="assetsnew/BlogImages/rp1.jpg" alt="">
                        <a href="">
                            <h5>Cras lobortis nisl nec libero pulvinar lacinia. Nunc sed ullamcorper massa</h5>
                        </a>
                    </div>
                    <div class="bgblog-2">
                        <img src="assetsnew/BlogImages/rp2.jpg" alt="">
                        <a href="">
                            <h5>Fusce tincidunt nulla magna, ac euismod quam viverra id. Fusce eget metus feugiat</h5>
                        </a>
                    </div>
                    <div class="bgblog-3">
                        <img src="assetsnew/BlogImages/rp3.jpg" alt="">
                        <a href="">
                            <h5>Etiam leo nibh, consectetur nec orci et, tempus tempus ex</h5>
                        </a>
                    </div>
                    <div class="bgblog-4">
                        <img src="assetsnew/BlogImages/rp4.jpg" alt="">
                        <a href="">
                            <h5>Sed viverra pellentesque dictum. Aenean ligula justo, viverra in lacus porttitor</h5>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>

<!-- Footer Including Starts Here -->

<?php 
include ("footer.php")
?>

<!-- Footer Including Ends Here -->


</body>

</html>