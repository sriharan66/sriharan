<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="cart.css">
</head>

<body>

    <!-- Header Including Starts Here -->

    <?php
    include("header.php")
        ?>

    <!-- Header Including Ends Here -->
    <div class="container-fluid cart-bg d-flex justify-content-center align-items-center text-center">
        <div class="div">
            <h2 class="fw-bold">CART</h2>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="cart">
                    <div class="cart-images">
                        <div class="cartimg-1 my-2">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-1.jpg" alt="">

                            <div class="img-details d-flex flex-column justify-content-center">
                                <span class="product-name">MANGO</span>
                                <h6>Button Through Strap Mini Dress</h6>
                                <p class="sizerf">SIZE: S</p>
                                <p class="color">COLOR: RED</p>
                                <p class="price">$45.00</p>
                            </div>
                        </div>
                        <div class="cartimg-2  my-2">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-2.jpg" alt="">
                            <div class="img-details d-flex flex-column justify-content-center">
                                <span class="product-name">MANGO</span>
                                <h6>Button Through Strap Mini Dress</h6>
                                <p class="sizerf">SIZE: S</p>
                                <p class="color">COLOR: RED</p>
                                <p class="price">$45.00</p>
                            </div>
                        </div>
                        <div class="cartimg-3  my-2">
                            <img class="img-fluid" src="assetsnew/ProductsImages/product-3.jpg" alt="">
                            <div class="img-details d-flex flex-column justify-content-center">
                                <span class="product-name">MANGO</span>
                                <h6>Button Through Strap Mini Dress</h6>
                                <p class="size">SIZE: S</p>
                                <p class="color">COLOR: RED</p>
                                <p class="price">$45.00</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 my-5 d-flex flex-column align-items-center">
                <div class="amount">
                    <h2 class="mb-3">Summary</h2>
                    <ul class="amount-calculation list-unstyled">
                        <li><span>SUBTOTAL:</span> <span class="fw-bold">$274.00</span></li>
                        <li><span>DELIVERY:</span> <span class="fw-bold">FREE</span></li>
                        <li><span>DISCOUNT:</span> <span class="fw-bold">-15%</span></li>
                        <li><span>TOTAL:</span> <span class="fw-bold">$232.00</span></li>
                    </ul>
                    <a href="checkout.php" class="btn my-3">CHECK OUT</a>
                </div>
            </div>
        </div>
    </div>


    <!-- Footer Including Starts Here -->

    <?php
    include("footer.php")
        ?>

    <!-- Footer Including Ends Here -->

</body>

</html>