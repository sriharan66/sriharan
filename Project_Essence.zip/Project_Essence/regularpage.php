<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RegularPage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="regularpage.css">

</head>

<body>
    <!-- Header Including Starts Here -->

 <?php
    include("header.php")
        ?>

    <!-- Header Including Ends Here -->
  
    <div class="container-fluid">
        <div class="row regular-bg">
        </div>
    </div>

    <div class="container my-3">
        <div class="row justify-content-center">
            <div class="col-lg-12 col-md-8 w-75">
                <div class="regular-textcontent">
                    <h2 class="my-3">Vivamus sed nunc in arcu cursus mollis quis et orci. Interdum et malesuada</h2>
                    <p class="my-3 lh-lg">Mauris viverra cursus ante laoreet eleifend. Donec vel fringilla ante. Aenean finibus velit id
                        urna vehicula, nec maximus est sollicitudin. Praesent at tempus lectus, eleifend blandit felis.
                        Fusce augue arcu, consequat a nisl aliquet, consectetur elementum turpis. Donec iaculis lobortis
                        nisl, et viverra risus imperdiet eu. Etiam mollis posuere elit non sagittis. Lorem ipsum dolor
                        sit amet, consectetur adipiscing elit. Nunc quis arcu a magna sodales venenatis. Integer non
                        diam sit amet magna luctus mollis ac eu nisi. In accumsan tellus ut dapibus blandit.</p>
                    <blockquote class="my-3">
                        <h6 class="d-flex"><i class="fa fa-quote-left text-primary fa-2x" aria-hidden="true"></i> Quisque sagittis non ex eget vestibulum.
                            Sed nec ultrices dui. Cras et sagittis erat. Maecenas pulvinar, turpis in dictum tincidunt,
                            dolor nibh lacinia lacus.</h6>
                        <span>Liam Neeson</span>
                    </blockquote>
                    <p class="my-3 lh-lg">Praesent ac magna sed massa euismod congue vitae vitae risus. Nulla lorem augue, mollis non est
                        et, eleifend elementum ante. Nunc id pharetra magna. Praesent vel orci ornare, blandit mi sed,
                        aliquet nisi. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos
                        himenaeos.</p>
                </div>
            </div>
        </div>
    </div>
<!-- Footer Including Starts Here -->

<?php 
include ("footer.php")
?>

<!-- Footer Including Ends Here -->


</body>

</html>