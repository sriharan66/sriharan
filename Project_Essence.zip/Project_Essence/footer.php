<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="footer.css">
</head>

<body>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 d-flex flex-row mt-lg-5 mt-4 gap-5">
                    <div class="col-lg-3  logo-img">
                        <img src="assetsnew/FooterImages/logo2.png" alt="logo">
                    </div>
                    <div class="col-lg-3 menu-link">
                        <ul class="list-unstyled d-flex flex-row gap-3">
                            <li><a href="#">Shop</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3  col-6 mt-lg-5">
                    <div class="order">
                        <ul class="list-unstyled">
                            <li><a href="#">Order Status</a></li>
                            <li><a href="#" class="text-nowrap">Shipping and Delivery</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-6 mt-lg-5">
                    <div class="payment">
                        <ul class="list-unstyled">
                            <li><a href="#">Payment Options</a></li>
                            <li><a href="#">Guides</a></li>
                            <li><a href="#">Terms of Use</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="subscribe mt-3 mt-lg-2">
                        <h6>SUBSCRIBE</h6>
                    </div>
                    <div class="form">
                        <form action="" method="">

                            <input type="email" name="email" placeholder="Your email here">
                            <button type="submit"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>

                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="socialmedia-icons mt-lg-4">
                        <ul class="list-unstyled d-flex flex-row gap-4  ">
                            <li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa-brands fa-pinterest"></i></a></li>
                            <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright text-center my-lg-5 my-4">
                        <p>Copyright &copy;2024 All rights reserved | made with <i class="fa-regular fa-heart"></i>by <a
                                href="#"> Colorlib</a>,distributed by <a href="#">ThemeWagon</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>