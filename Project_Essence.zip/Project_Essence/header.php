<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="header.css">
</head>

<body>
    <header>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <nav class="navbar navbar-expand-lg ">
                        <a class="navbar-brand" href="index.php"> <img src="assetsnew/HeaderImages/logo.png" alt="">
                        </a>
                        <button class="btn d-lg-none" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                            <i class="fa-solid fa-bars fa-2x"></i>
                        </button>

                        <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar"
                            aria-labelledby="offcanvasNavbarLabel">

                            <div class="offcanvas-header">
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                    aria-label="Close"></button>
                            </div>

                            <div class="offcanvas-body">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item collection-items">
                                        <a class="nav-link menu-shop" href="shop.php">Shop <i
                                                class="fa-solid fa-angle-down"></i>
                                        </a>

                                        <div class="collection-menu">
                                            <ul class="collection-1 list-unstyled">
                                                <li class="title"><a href="">Women's Collection</a></li>
                                                <li><a href="">Dresses</a></li>
                                                <li><a href="">Blouses &amp; Shirts</a></li>
                                                <li><a href="">T-shirts</a></li>
                                                <li><a href="">Rompers</a></li>
                                                <li><a href="">Bras &amp; Panties</a></li>
                                            </ul>
                                            <ul class="collection-2 list-unstyled">
                                                <li class="title"><a href="">Men's Collection</a></li>
                                                <li><a href="">T-Shirts</a></li>
                                                <li><a href="">Polo</a></li>
                                                <li><a href="">Shirts</a></li>
                                                <li><a href="">Jackets</a></li>
                                                <li><a href="">Trench</a></li>
                                            </ul>
                                            <ul class="collection-3 list-unstyled">
                                                <li class="title"><a href="">Kid's Collection</a></li>
                                                <li><a href="">Dresses</a></li>
                                                <li><a href="">Shirts</a></li>
                                                <li><a href="">T-shirts</a></li>
                                                <li><a href="">Jackets</a></li>
                                                <li><a href="">Trench</a></li>
                                            </ul>
                                            <ul class="collection-4 list-unstyled">
                                                <img class="img-fluid" src="assetsnew/BackgroundImages/bg-4.jpg" alt="">
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link" href="#">Pages <i class="fa-solid fa-angle-down"></i></a>
                                        <ul class="dropdown-list list-unstyled" id="link">
                                            <li><a href="productdetails.php">Product Details</a></li>
                                            <li><a href="checkout.php">Checkout</a></li>
                                            <li class="last-dropdown"><a href="regularpage.php">Regular Page</a></li>

                                        </ul>
                                        <span class="unknown"></span>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="blog.php">Blog</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="contacts.php">Contact</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="col-lg-6">
                    <div class="user-section d-flex clearfix justify-content-end">
                        <div class="search">
                            <form action="#" method="post">
                                <input type="search" name="search" id="searchbar" placeholder="Type for search">
                                <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </form>
                        </div>
                        <div class="heart">
                            <a href="#"><img src="assetsnew/HeaderImages/heart.svg" alt=""></a>
                        </div>
                        <div class="user">
                            <a href="#"><img src="assetsnew/HeaderImages/user.svg" alt=""></a>
                        </div>
                        <div class="bag">
                            <a href="cart.php"><img src="assetsnew/HeaderImages/bag.svg" alt=""></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </header>



</body>

</html>